# RussianKid
Hello everyone! I just fucking tired with this small project, but now i can tell about him

DefLauncher official cooperation

Minecraft Launcher on python!!!!🥳🥳🥳🥳

You can download him and play with any nickname and versions of Minecraft!!!!
main.py - is more easy to recreate
main2.py - harder but you can customize them!!!!
Free to use
Needs: py 3.12 (minecraft_launcher_lib, PyQt5 import QtCore, QtGui, QtWidgets, random_username.generate import generate_username, uuid import uuid1, subprocess)
#minecraft-launcher

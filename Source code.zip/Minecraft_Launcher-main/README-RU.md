#RussianKid
Привет всем! Я просто чертовски устал от этого небольшого проекта, но теперь я могу рассказать о нем

Официальное сотрудничество с Deflauncher

Майнкрафт лаунчер на python!!!!🥳🥳🥳🥳

Вы можете скачать его и играть с любым ником и версиями Майнкрафта!!!!
main.py - легче воссоздать
main2.py - сложнее, но вы можете настроить их!!!!
Бесплатно использовать
Требуется: py 3.12 (minecraft_launcher_lib, PyQt5 import QtCore, QtGui, QtWidgets, random_username.generate import generate_username, uuid import uuid1, subprocess)
